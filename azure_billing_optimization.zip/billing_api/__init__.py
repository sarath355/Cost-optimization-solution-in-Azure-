
import os
import json
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import azure.functions as func

COSMOS_URL = os.getenv('COSMOS_URL')
COSMOS_KEY = os.getenv('COSMOS_KEY')
DATABASE_NAME = 'BillingDB'
CONTAINER_NAME = 'Records'

BLOB_CONNECTION_STRING = os.getenv('BLOB_CONNECTION_STRING')
BLOB_CONTAINER_NAME = 'billing-archive'

def main(req: func.HttpRequest) -> func.HttpResponse:
    user_id = req.route_params.get('userId')
    record_id = req.route_params.get('id')

    cosmos_client = CosmosClient(COSMOS_URL, credential=COSMOS_KEY)
    container = cosmos_client.get_database_client(DATABASE_NAME).get_container_client(CONTAINER_NAME)

    try:
        item = container.read_item(item=record_id, partition_key=user_id)
        return func.HttpResponse(json.dumps(item), mimetype="application/json")
    except:
        blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=BLOB_CONTAINER_NAME, blob=f"{user_id}/{record_id}.json")
        if blob_client.exists():
            blob_data = blob_client.download_blob().readall()
            return func.HttpResponse(blob_data, mimetype="application/json")
        else:
            return func.HttpResponse("Record not found", status_code=404)
