
import logging
import os
import json
from datetime import datetime, timedelta
import azure.functions as func
from azure.cosmos import CosmosClient, PartitionKey
from azure.storage.blob import BlobServiceClient

COSMOS_URL = os.getenv('COSMOS_URL')
COSMOS_KEY = os.getenv('COSMOS_KEY')
DATABASE_NAME = 'BillingDB'
CONTAINER_NAME = 'Records'

BLOB_CONNECTION_STRING = os.getenv('BLOB_CONNECTION_STRING')
BLOB_CONTAINER_NAME = 'billing-archive'

def main(mytimer: func.TimerRequest) -> None:
    logging.info('Archival function triggered.')
    date_threshold = (datetime.utcnow() - timedelta(days=90)).isoformat()

    cosmos_client = CosmosClient(COSMOS_URL, credential=COSMOS_KEY)
    container = cosmos_client.get_database_client(DATABASE_NAME).get_container_client(CONTAINER_NAME)
    blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
    blob_container_client = blob_service_client.get_container_client(BLOB_CONTAINER_NAME)
    blob_container_client.create_container()

    query = f"SELECT * FROM c WHERE c.timestamp < '{date_threshold}'"
    for item in container.query_items(query=query, enable_cross_partition_query=True):
        record_id = item["id"]
        user_id = item["userId"]
        blob_name = f"{user_id}/{record_id}.json"

        blob_client = blob_container_client.get_blob_client(blob_name)
        blob_client.upload_blob(json.dumps(item), overwrite=True)
        container.delete_item(item=record_id, partition_key=user_id)

    logging.info("Old billing records archived successfully.")
